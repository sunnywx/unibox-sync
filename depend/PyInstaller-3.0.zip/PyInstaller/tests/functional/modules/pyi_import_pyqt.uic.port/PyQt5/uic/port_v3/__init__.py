__pyinstaller_fake_module_marker__ = '__pyinstaller_fake_module_marker__'
print('this is PyQtx.uic.port_v2')
from . import test
